<?php
/**
 * config/config.php
 *
 * Global site configuration.
 * This file must be included before any other application file
 * (it is loaded automatically by config/database.php).
 */

// Prevent direct access to this file
if (!defined('ONLINE_EXAM_APP')) {
    define('ONLINE_EXAM_APP', true);
}

// ---------------------------------------------------------------------
// Environment
// ---------------------------------------------------------------------
// Set to false in production. When true, PHP errors are displayed;
// when false, errors are logged only (see error_log below).
define('APP_DEBUG', true);

// ---------------------------------------------------------------------
// Database credentials
// ---------------------------------------------------------------------
// Do NOT hardcode credentials anywhere else in the project.
// Every file that needs a DB connection includes config/database.php,
// which reads these constants.
define('DB_HOST', 'localhost');
define('DB_NAME', 'online_exam');
define('DB_USER', 'root');
define('DB_PASS', ''); // Default XAMPP root password is empty. Change for production.
define('DB_CHARSET', 'utf8mb4');

// ---------------------------------------------------------------------
// Application paths / URLs
// ---------------------------------------------------------------------
// BASE_URL should point to the project root as seen by the browser.
// Adjust this if the project folder name or server config differs.
define('BASE_URL', 'http://localhost/online-exam');

define('ROOT_PATH', dirname(__DIR__));               // Absolute filesystem path to project root
define('UPLOAD_PATH', ROOT_PATH . '/assets/images/'); // Where uploaded images are stored
define('UPLOAD_URL', BASE_URL . '/assets/images/');

// ---------------------------------------------------------------------
// Session configuration
// ---------------------------------------------------------------------
define('SESSION_NAME', 'online_exam_session');
define('SESSION_LIFETIME', 7200); // 2 hours, in seconds

// ---------------------------------------------------------------------
// Application-wide constants
// ---------------------------------------------------------------------
define('APP_NAME', 'Online Exam Platform');
define('DEFAULT_TIMEZONE', 'Asia/Dhaka');
define('RECORDS_PER_PAGE', 10); // Default pagination size

// ---------------------------------------------------------------------
// Error reporting
// ---------------------------------------------------------------------
date_default_timezone_set(DEFAULT_TIMEZONE);

if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', ROOT_PATH . '/error.log');
}
