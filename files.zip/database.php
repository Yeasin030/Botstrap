<?php
/**
 * config/database.php
 *
 * Central PDO database connection.
 *
 * Usage from any file in the project:
 *
 *     require_once __DIR__ . '/../config/database.php'; // adjust path as needed
 *     $db = Database::getConnection();
 *     $stmt = $db->prepare("SELECT * FROM users WHERE id = :id");
 *     $stmt->execute([':id' => $id]);
 *     $user = $stmt->fetch();
 *
 * Uses a singleton PDO connection so every include reuses the same
 * connection instead of opening a new one per query.
 */

require_once __DIR__ . '/config.php';

class Database
{
    /** @var PDO|null */
    private static ?PDO $connection = null;

    /**
     * Get the shared PDO connection instance.
     * Creates it on first call, reuses it afterwards.
     */
    public static function getConnection(): PDO
    {
        if (self::$connection === null) {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

            $options = [
                // Throw exceptions on error instead of silent failure /
                // manual error checking. This lets us use try/catch
                // consistently across the app.
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,

                // Return associative arrays by default (not both
                // numeric + associative keys).
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

                // Use real prepared statements, not emulated ones.
                // This is important for security (proper type binding)
                // and for consistent behavior across MySQL versions.
                PDO::ATTR_EMULATE_PREPARES => false,

                // Keep persistent connections off; each request opens
                // and closes its own connection cleanly.
                PDO::ATTR_PERSISTENT => false,
            ];

            try {
                self::$connection = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                // Never leak raw DB errors (credentials, schema, etc.)
                // to the end user. Log the real error, show a generic
                // message instead.
                self::logError($e->getMessage());

                if (APP_DEBUG) {
                    // Only show the real error while developing locally.
                    die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
                }

                die('A database error occurred. Please try again later.');
            }
        }

        return self::$connection;
    }

    /**
     * Log a database-related error message to the error log file
     * instead of exposing it to the browser.
     */
    private static function logError(string $message): void
    {
        $logFile = ROOT_PATH . '/error.log';
        $timestamp = date('Y-m-d H:i:s');
        error_log("[{$timestamp}] DB ERROR: {$message}" . PHP_EOL, 3, $logFile);
    }

    /**
     * Prevent instantiation. This class is used statically only.
     */
    private function __construct()
    {
    }

    /**
     * Prevent cloning of the singleton.
     */
    private function __clone()
    {
    }
}
